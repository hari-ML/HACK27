'use client'

import { useEffect, useMemo, useState, type ReactNode } from 'react'
import hackLogo from '../assets/hack-2027-logo.png'
import simatsLogo from '../assets/simats-engineering-logo.png'

// Edit official event details and links here as they are confirmed.
const eventConfig = {
  eventDate: null as string | null,
  registrationStatus: 'Coming Soon' as 'Coming Soon' | 'Open' | 'Closed',
  registrationUrl: '',
  email: 'Simatshack2027@gmail.com',
  instagramUrl: 'https://www.instagram.com/hack2027_simats?mdxt=MWZ5cHF2cXBkcWx2cg==',
  whatsappUrl: 'https://chat.whatsapp.com/FhHEM1K3y5125qcIR1ulEa',
  linkedinUrl: '',
  phone: '',
}

const navItems = [
  ['Home', 'home'],
  ['About', 'about'],
  ['Domains', 'domains'],
  ['Timeline', 'timeline'],
  ['Prizes', 'prizes'],
  ['Organizing Team', 'team'],
  ['Contact', 'contact'],
] as const

const features = [
  [
    '01',
    '24 Hours of Innovation',
    'A focused sprint designed to turn ambitious ideas into working solutions.',
    'bolt',
  ],
  [
    '02',
    'Team Collaboration',
    'Build alongside developers, designers and fearless problem-solvers.',
    'users',
  ],
  [
    '03',
    'Mentorship & Guidance',
    'Learn, iterate and move forward with support throughout the challenge.',
    'compass',
  ],
  [
    '04',
    'Innovation & Recognition',
    'Present bold thinking and celebrate meaningful technical execution.',
    'spark',
  ],
]

const domains = [
  [
    'Web Development',
    'Create fast, accessible and transformative experiences for the open web.',
    'code',
  ],
  ['App Development', 'Design powerful mobile products for people on the move.', 'phone'],
  [
    'Cybersecurity',
    'Protect systems, identities and data in an increasingly connected world.',
    'shield',
  ],
  [
    'Blockchain Technology',
    'Explore trusted, transparent and decentralized digital systems.',
    'blocks',
  ],
  [
    'Open Innovation',
    'Bring an original challenge and build beyond conventional boundaries.',
    'orbit',
  ],
]

const committee = [
  { name: 'ARSHATH ALI A', designation: 'Chief Organizer & Event Director' },
  { name: 'KAREEMULLAH AR', designation: 'Operations & Venue Coordinator' },
  { name: 'VISWAJITH K', designation: 'Technical Head' },
  { name: 'RESHEKESH B', designation: 'Registration & Participant Coordinator' },
  { name: 'SUDHARSHINI R', designation: 'Media & Public Relations Head' },
  { name: 'KEERTHANA R', designation: 'Sponsorship & Partnership Coordinator' },
  { name: 'ANURUPA T', designation: 'Hospitality & Accommodation Coordinator' },
  { name: 'C RAKSHITHA', designation: 'Documentation & Certificate Coordinator' },
]

const techSkills = [
  ['HTML', 'code'],
  ['CSS', 'spark'],
  ['JavaScript', 'blocks'],
  ['Python', 'terminal'],
  ['Java', 'bolt'],
  ['React', 'orbit'],
  ['Node.js', 'signal'],
  ['SQL', 'database'],
  ['Git & GitHub', 'git'],
  ['Cloud Computing', 'cloud'],
  ['Cybersecurity', 'shield'],
]

const timeline = [
  'Registration Opens',
  'Registration Closes',
  'Participant Check-in',
  'Opening Ceremony',
  'Problem Statement Release',
  'Hackathon Begins',
  'Project Submission',
  'Final Evaluation',
  'Winners Announcement',
]

const rules = [
  'Eligibility Criteria',
  'Team Formation',
  'Team Size',
  'Registration Rules',
  'Project Development',
  'Submission Guidelines',
  'Judging Criteria',
  'Code of Conduct',
]

const faqs = [
  {
    question: 'What is HACK 2027?',
    answer:
      'HACK.2027 is a premier 24-hour national-level hackathon bringing together brilliant student developers, designers, and innovators to build disruptive tech solutions and functional prototypes for real-world challenge statements.',
  },
  {
    question: 'Who can participate?',
    answer:
      'The hackathon is open to all undergraduate and postgraduate students from engineering, science, and technology disciplines who are passionate about coding, design, and problem-solving.',
  },
  {
    question: 'Is this a 24-hour hackathon?',
    answer:
      'Yes! HACK.2027 is an intensive, non-stop 24-hour coding and prototyping sprint where teams race against the clock to build their solutions.',
  },
  {
    question: 'How do I register?',
    answer: 'You can register your team online through our Devfolio Page.',
  },
  {
    question: 'Can students from different colleges participate?',
    answer:
      'Yes, cross-institutional teams are welcome. Team members can be from different colleges, universities, or degree programs.',
  },
  {
    question: 'What is the team size?',
    answer: 'Teams can consist of 2 to 4 members.',
  },
  {
    question: 'What should participants bring?',
    answer: 'Participants must bring their own laptops, chargers, extension box,college ID card.',
  },
  {
    question: 'Will accommodation be provided?',
    answer:
      'Yes, overnight accommodation and resting spaces will be provided on campus for out-of-station participants during the duration of the hackathon.',
  },
  {
    question: 'How will projects be evaluated?',
    answer:
      'Projects will be judged by a panel of industry experts and faculty mentors based on four core pillars: Innovation & Uniqueness, Technical Execution & Working Prototype, Impact & Feasibility, and the Final Presentation/Pitch.',
  },
  {
    question: 'Will certificates be provided?',
    answer:
      'Yes! All participants who successfully submit a completed project will receive digital certificates of participation. Finalists and winning teams will receive special certificates of excellence alongside exciting prizes.',
  },
]

function Icon({ name, size = 22 }: { name: string; size?: number }) {
  const paths: Record<string, ReactNode> = {
    arrow: (
      <>
        <path d="M5 12h14M13 6l6 6-6 6" />
      </>
    ),
    bolt: <path d="m13 2-9 12h7l-1 8 9-12h-7l1-8Z" />,
    users: (
      <>
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
      </>
    ),
    compass: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="m16 8-2.7 5.3L8 16l2.7-5.3L16 8Z" />
      </>
    ),
    spark: (
      <path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3ZM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8L19 16Z" />
    ),
    brain: (
      <>
        <path d="M9.5 4.5A3 3 0 0 0 4 6a3 3 0 0 0 0 6 3 3 0 0 0 2 5.8V19a2 2 0 0 0 4 0V5.5a2 2 0 0 0-.5-1Z" />
        <path d="M14.5 4.5A3 3 0 0 1 20 6a3 3 0 0 1 0 6 3 3 0 0 1-2 5.8V19a2 2 0 0 1-4 0V5.5a2 2 0 0 1 .5-1Z" />
      </>
    ),
    code: (
      <>
        <path d="m8 9-4 3 4 3M16 9l4 3-4 3M14 5l-4 14" />
      </>
    ),
    phone: (
      <>
        <rect x="6" y="2" width="12" height="20" rx="2" />
        <path d="M10 18h4" />
      </>
    ),
    shield: <path d="M12 22s8-3.8 8-10V5l-8-3-8 3v7c0 6.2 8 10 8 10Zm-3-10 2 2 4-4" />,
    signal: (
      <>
        <path d="M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0" />
        <circle cx="12" cy="20" r="1" />
      </>
    ),
    blocks: (
      <>
        <rect x="3" y="3" width="7" height="7" />
        <rect x="14" y="3" width="7" height="7" />
        <rect x="8.5" y="14" width="7" height="7" />
        <path d="M10 6.5h4M6.5 10v3.5m11-3.5v3.5" />
      </>
    ),
    orbit: (
      <>
        <circle cx="12" cy="12" r="2" />
        <ellipse cx="12" cy="12" rx="10" ry="4.5" transform="rotate(45 12 12)" />
        <ellipse cx="12" cy="12" rx="10" ry="4.5" transform="rotate(-45 12 12)" />
      </>
    ),
    plus: (
      <>
        <path d="M12 5v14M5 12h14" />
      </>
    ),
    chevron: <path d="m6 9 6 6 6-6" />,
    menu: (
      <>
        <path d="M4 7h16M4 12h16M4 17h16" />
      </>
    ),
    close: (
      <>
        <path d="m6 6 12 12M18 6 6 18" />
      </>
    ),
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    trophy: (
      <>
        <path d="M8 4h8v5a4 4 0 0 1-8 0V4Z" />
        <path d="M8 6H4v1a4 4 0 0 0 4 4m8-5h4v1a4 4 0 0 1-4 4M12 13v5m-4 2h8" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    mail: (
      <>
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <path d="m3 7 9 6 9-6" />
      </>
    ),
    instagram: (
      <>
        <rect x="3" y="3" width="18" height="18" rx="5" />
        <circle cx="12" cy="12" r="4" />
        <circle cx="17.5" cy="6.5" r=".5" fill="currentColor" />
      </>
    ),
    message: (
      <>
        <path d="M21 11.5a8.5 8.5 0 0 1-12.6 7.4L3 21l2.1-5.4A8.5 8.5 0 1 1 21 11.5Z" />
      </>
    ),
    linkedin: (
      <>
        <rect x="3" y="3" width="18" height="18" rx="2" />
        <path d="M8 11v6M8 8v.1M12 17v-6m0 3a3 3 0 0 1 6 0v3" />
      </>
    ),
    terminal: (
      <>
        <path d="m5 7 4 5-4 5M11 17h8" />
        <rect x="2.5" y="3.5" width="19" height="17" rx="2" />
      </>
    ),
    database: (
      <>
        <ellipse cx="12" cy="5" rx="8" ry="3" />
        <path d="M4 5v7c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12v7c0 1.7 3.6 3 8 3s8-1.3 8-3v-7" />
      </>
    ),
    git: (
      <>
        <circle cx="6" cy="5" r="2" />
        <circle cx="18" cy="7" r="2" />
        <circle cx="8" cy="19" r="2" />
        <path d="M6 7v3a4 4 0 0 0 4 4h2a6 6 0 0 0 6-5M8 17v-3" />
      </>
    ),
    cloud: <path d="M7 18h11a4 4 0 0 0 .5-8A7 7 0 0 0 5 9a4.5 4.5 0 0 0 2 9Z" />,
  }
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {paths[name] ?? paths.spark}
    </svg>
  )
}

function SectionHeader({
  eyebrow,
  title,
  copy,
}: {
  eyebrow: string
  title: string
  copy?: string
}) {
  return (
    <div className="section-head reveal">
      <span className="eyebrow">
        <i />
        {eyebrow}
      </span>
      <h2>{title}</h2>
      {copy && <p>{copy}</p>}
    </div>
  )
}

function Accordion({
  items,
  type,
}: {
  items: string[] | { question: string; answer: string }[]
  type: 'rule' | 'faq'
}) {
  const [open, setOpen] = useState<number | null>(null)
  return (
    <div className={`accordion ${type === 'faq' ? 'faq-accordion' : ''}`}>
      {items.map((item, index) => {
        const question = typeof item === 'string' ? item : item.question
        const answer =
          typeof item === 'string'
            ? 'Official details will be published here once confirmed by the organizing team.'
            : item.answer
        const buttonId = `${type}-question-${index + 1}`
        const answerId = `${type}-answer-${index + 1}`
        return (
          <div className={`accordion-item ${open === index ? 'open' : ''}`} key={question}>
            <button
              id={buttonId}
              type="button"
              onClick={() => setOpen(open === index ? null : index)}
              aria-expanded={open === index}
              aria-controls={answerId}
            >
              <span>
                <b>{String(index + 1).padStart(2, '0')}</b>
                {question}
              </span>
              <i>
                <Icon name={type === 'faq' ? 'chevron' : 'plus'} size={18} />
              </i>
            </button>
            <div
              className="accordion-answer"
              id={answerId}
              role="region"
              aria-labelledby={buttonId}
              aria-hidden={open !== index}
            >
              <p>{answer}</p>
            </div>
          </div>
        )
      })}
    </div>
  )
}

function ActionLink({
  href,
  children,
  className = '',
}: {
  href: string
  children: ReactNode
  className?: string
}) {
  if (!href)
    return (
      <button
        className={`${className} is-disabled`}
        disabled
        title="Link will be added when confirmed"
      >
        {children}
      </button>
    )
  return (
    <a className={className} href={href} target="_blank" rel="noreferrer">
      {children}
    </a>
  )
}

export function Hack2027App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [active, setActive] = useState('home')
  const [loaded, setLoaded] = useState(false)
  const [showTop, setShowTop] = useState(false)
  const [countdown, setCountdown] = useState({
    days: '--',
    hours: '--',
    minutes: '--',
    seconds: '--',
  })

  useEffect(() => {
    const loadTimer = window.setTimeout(() => setLoaded(true), 900)
    const onScroll = () => {
      setScrolled(window.scrollY > 30)
      setShowTop(window.scrollY > 700)
      const sections = navItems
        .map(([, id]) => document.getElementById(id))
        .filter(Boolean) as HTMLElement[]
      const current = [...sections]
        .reverse()
        .find((section) => section.getBoundingClientRect().top <= 180)
      if (current) setActive(current.id)
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    onScroll()
    const observer = new IntersectionObserver(
      (entries) =>
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add('visible')
        }),
      { threshold: 0.12 },
    )
    document.querySelectorAll('.reveal').forEach((el) => observer.observe(el))
    return () => {
      clearTimeout(loadTimer)
      window.removeEventListener('scroll', onScroll)
      observer.disconnect()
    }
  }, [])

  useEffect(() => {
    if (!eventConfig.eventDate) return
    const update = () => {
      const distance = Math.max(0, new Date(eventConfig.eventDate!).getTime() - Date.now())
      setCountdown({
        days: String(Math.floor(distance / 86400000)).padStart(2, '0'),
        hours: String(Math.floor(distance / 3600000) % 24).padStart(2, '0'),
        minutes: String(Math.floor(distance / 60000) % 60).padStart(2, '0'),
        seconds: String(Math.floor(distance / 1000) % 60).padStart(2, '0'),
      })
    }
    update()
    const timer = window.setInterval(update, 1000)
    return () => clearInterval(timer)
  }, [])

  const prizeCards = useMemo(
    () => [
      ['SECOND PRIZE', '02', 'silver'],
      ['FIRST PRIZE', '01', 'gold'],
      ['THIRD PRIZE', '03', 'bronze'],
    ],
    [],
  )

  return (
    <div className="site-shell">
      <div className={`loader ${loaded ? 'loaded' : ''}`}>
        <img src={hackLogo.src} alt="" />
        <span />
      </div>

      <header className={`nav ${scrolled ? 'scrolled' : ''}`}>
        <a className="nav-logo" href="#home" aria-label="HACK 2027 home">
          <img src={hackLogo.src} alt="HACK 2027" />
        </a>
        <nav className={menuOpen ? 'open' : ''} aria-label="Primary navigation">
          {navItems.map(([label, id]) => (
            <a
              key={id}
              href={`#${id}`}
              className={active === id ? 'active' : ''}
              onClick={() => setMenuOpen(false)}
            >
              {label}
            </a>
          ))}
        </nav>
        <button
          className="menu-button"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
          aria-expanded={menuOpen}
        >
          <Icon name={menuOpen ? 'close' : 'menu'} />
        </button>
      </header>

      <main>
        <section id="home" className="hero">
          <div className="grid-bg" />
          <div className="orb orb-one" />
          <div className="orb orb-two" />
          <div className="hero-lines">
            <i />
            <i />
            <i />
          </div>
          <div className="hero-content">
            <div className="hero-kicker">
              <span>24-HOUR HACKATHON</span>
              <span className="pulse">
                <i /> COMING SOON
              </span>
            </div>
            <div className="hero-brand">
              <div className="hero-institution-label">
                <img src={simatsLogo.src} alt="SIMATS Engineering" />
              </div>
              <div className="logo-orbit">
                <span className="orbit-ring orbit-ring-outer" aria-hidden="true">
                  <i />
                  <i />
                  <i />
                </span>
                <span className="orbit-ring orbit-ring-inner" aria-hidden="true" />
                <img className="hero-logo" src={hackLogo.src} alt="HACK 2027" />
              </div>
            </div>
            <h1>
              <span>INNOVATE. BUILD.</span>
              <em>BREAK LIMITS.</em>
            </h1>
            <p>
              24 Hours. Limitless Innovation.
              <br className="mobile-only" /> One Platform to Build the Future.
            </p>
            <div className="countdown" aria-label="Event countdown">
              {Object.entries(countdown).map(([label, value]) => (
                <div key={label}>
                  <strong key={value}>{value}</strong>
                  <span>{label}</span>
                </div>
              ))}
            </div>
            {!eventConfig.eventDate && <div className="date-note">EVENT DATE TO BE ANNOUNCED</div>}
            <div className="hero-actions">
              <a className="button" href="#registration">
                Register Now <Icon name="arrow" size={18} />
              </a>
              <a className="button button-ghost" href="#about">
                Explore Event <span>↓</span>
              </a>
            </div>
          </div>
          <div className="scroll-cue">
            <span>SCROLL TO EXPLORE</span>
            <i />
          </div>
        </section>

        <section className="institution">
          <div className="institution-inner reveal">
            <div className="institution-copy">
              <span>ORGANIZING INSTITUTION</span>
              <h3>ORGANIZED BY</h3>
              <p>Department of Smart Materials · SIMATS Engineering</p>
            </div>
            <div className="simats-wrap">
              <img src={simatsLogo.src} alt="SIMATS Engineering – Engineer to Excel" />
            </div>
          </div>
        </section>

        <section id="about" className="section about">
          <SectionHeader
            eyebrow="About the event"
            title="MORE THAN JUST A HACKATHON."
            copy="HACK 2027 brings together passionate developers, designers, innovators and problem-solvers for an intensive 24-hour innovation experience. Collaborate with talented minds, develop creative solutions and transform ideas into impactful technology."
          />
          <div className="feature-grid">
            {features.map(([number, title, copy, icon]) => (
              <article className="feature-card reveal" key={number}>
                <div className="card-top">
                  <span>{number}</span>
                  <i>
                    <Icon name={icon} />
                  </i>
                </div>
                <h3>{title}</h3>
                <p>{copy}</p>
                <div className="card-line" />
              </article>
            ))}
          </div>
        </section>

        <section className="section highlights">
          <SectionHeader
            eyebrow="Event highlights"
            title="THE EXPERIENCE. THE CHALLENGE. THE INNOVATION."
          />
          <div className="stats-grid reveal">
            {[
              ['24', 'HOURS', 'clock'],
              ['05', 'DOMAINS', 'orbit'],
              ['TEAM', 'BASED INNOVATION', 'users'],
              ['TBA', 'EXCITING REWARDS', 'trophy'],
            ].map(([value, label, icon]) => (
              <div className="stat" key={label}>
                <Icon name={icon} size={26} />
                <strong>{value}</strong>
                <span>{label}</span>
              </div>
            ))}
          </div>
          <p className="data-note">
            Confirmed details and statistics will be updated by the organizing team.
          </p>
        </section>

        <section id="domains" className="section domains">
          <SectionHeader
            eyebrow="Innovation tracks"
            title="CHOOSE YOUR BATTLEFIELD."
            copy="Five directions. One relentless goal: build something that matters."
          />
          <div className="domain-grid">
            {domains.map(([title, copy, icon], index) => (
              <article className="domain-card reveal" key={title}>
                <span className="domain-number">0{index + 1}</span>
                <div className="domain-icon">
                  <Icon name={icon} size={29} />
                </div>
                <h3>{title}</h3>
                <p>{copy}</p>
                <button>
                  Explore Domain <Icon name="arrow" size={18} />
                </button>
              </article>
            ))}
          </div>
        </section>

        <section className="section tech-section">
          <SectionHeader
            eyebrow="Technical toolkit"
            title="TECH SKILLS & TECHNOLOGIES"
            copy="Explore the technologies that can help turn an ambitious idea into a working solution."
          />
          <div className="tech-grid">
            {techSkills.map(([skill, icon], index) => (
              <article className="tech-card reveal" key={skill}>
                <span>{String(index + 1).padStart(2, '0')}</span>
                <i>
                  <Icon name={icon} size={25} />
                </i>
                <h3>{skill}</h3>
              </article>
            ))}
          </div>
          <p className="tech-note">
            Technology skills are separate from the five official hackathon domains.
          </p>
        </section>

        <section id="timeline" className="section timeline-section">
          <SectionHeader
            eyebrow="Road to HACK 2027"
            title="24 HOURS. ONE JOURNEY."
            copy="Every milestone will be updated with official dates and times as soon as they are confirmed."
          />
          <div className="timeline">
            {timeline.map((item, index) => (
              <div className="timeline-item reveal" key={item}>
                <div className="timeline-marker">
                  <span>{String(index + 1).padStart(2, '0')}</span>
                </div>
                <div className="timeline-card">
                  <span>DATE & TIME — TBA</span>
                  <h3>{item}</h3>
                  <p>Official schedule details will be announced.</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        <section id="prizes" className="section prizes">
          <SectionHeader
            eyebrow="Prizes & rewards"
            title="YOUR INNOVATION DESERVES RECOGNITION."
            copy="Recognition designed to celebrate the strongest ideas, execution and impact."
          />
          <div className="prize-grid">
            {prizeCards.map(([title, rank, tone]) => (
              <article className={`prize-card ${tone} reveal`} key={title}>
                <span className="prize-rank">{rank}</span>
                <Icon name="trophy" size={40} />
                <h3>{title}</h3>
                <strong>PRIZE VALUE — TBA</strong>
                <ul>
                  <li>
                    <Icon name="check" size={15} /> Cash Prize — TBA
                  </li>
                  <li>
                    <Icon name="check" size={15} /> Goodies — TBA
                  </li>
                  <li>
                    <Icon name="check" size={15} /> Certificates
                  </li>
                  <li>
                    <Icon name="check" size={15} /> Special Recognition — TBA
                  </li>
                </ul>
              </article>
            ))}
          </div>
        </section>

        <section className="section participate">
          <SectionHeader eyebrow="How to participate" title="YOUR JOURNEY STARTS HERE." />
          <div className="steps">
            {[
              ['REGISTER', 'Complete the online registration.'],
              ['BUILD YOUR TEAM', 'Form your team according to official guidelines.'],
              ['CHOOSE YOUR DOMAIN', 'Select your preferred innovation domain.'],
              ['BUILD & COMPETE', 'Bring your ideas to life in 24 hours.'],
            ].map(([title, copy], index) => (
              <div className="step reveal" key={title}>
                <span>STEP {String(index + 1).padStart(2, '0')}</span>
                <i>{index + 1}</i>
                <h3>{title}</h3>
                <p>{copy}</p>
              </div>
            ))}
          </div>
          <a href="#registration" className="button journey-cta">
            Register Your Team <Icon name="arrow" size={18} />
          </a>
        </section>

        <section id="registration" className="registration section">
          <div className="registration-panel reveal">
            <div className="registration-copy">
              <span className="eyebrow">
                <i />
                Registration portal
              </span>
              <div className="status">
                <i />
                {eventConfig.registrationStatus}
              </div>
              <h2>
                READY TO BUILD
                <br />
                THE <em>FUTURE?</em>
              </h2>
              <p>
                Registration instructions and the official application link will appear here once
                released by the HACK 2027 organizing team.
              </p>
              <ActionLink href={eventConfig.registrationUrl} className="button">
                Registration Coming Soon <Icon name="arrow" size={18} />
              </ActionLink>
            </div>
            <div className="registration-info">
              {[
                ['ELIGIBILITY', 'Official eligibility details — TBA'],
                ['TEAM INFORMATION', 'Official team size and formation rules — TBA'],
                ['REGISTRATION', 'External registration portal — Coming Soon'],
              ].map(([title, copy]) => (
                <div key={title}>
                  <Icon name="check" />
                  <span>
                    <b>{title}</b>
                    {copy}
                  </span>
                </div>
              ))}
              <small>No application is submitted on this website.</small>
            </div>
          </div>
        </section>

        <section id="guidelines" className="section rules-section">
          <SectionHeader
            eyebrow="Rules & guidelines"
            title="KNOW THE RULES. PLAY FAIR."
            copy="Official event policies will be added here as they are approved."
          />
          <Accordion items={rules} type="rule" />
        </section>

        <section className="section judging">
          <SectionHeader
            eyebrow="Evaluation framework"
            title="IDEAS ARE NOTHING WITHOUT EXECUTION."
          />
          <div className="judging-grid">
            {[
              'Innovation & Creativity',
              'Technical Implementation',
              'Problem Relevance',
              'Practical Feasibility',
              'Presentation & Demonstration',
            ].map((title, index) => (
              <article className="judge-card reveal" key={title}>
                <span>0{index + 1}</span>
                <div>
                  <h3>{title}</h3>
                  <p>Weightage — To be confirmed</p>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="section sponsors">
          <SectionHeader
            eyebrow="Sponsors & partners"
            title="POWERING THE NEXT GENERATION OF INNOVATION."
          />
          <div className="sponsor-grid">
            {[
              'Title Sponsor',
              'Gold Sponsor',
              'Technology Partner',
              'Community Partner',
              'Media Partner',
            ].map((title) => (
              <a
                className="sponsor-slot reveal"
                href="mailto:Simatshack2027@gmail.com?subject=HACK%202027%20Sponsorship%20Enquiry"
                aria-label={`Enquire about becoming a ${title} for HACK 2027`}
                key={title}
              >
                <span>{title}</span>
                <div>
                  <Icon name="plus" />
                  <b>PARTNER LOGO</b>
                  <small>COMING SOON</small>
                  <small className="sponsor-enquiry">Enquire Now</small>
                </div>
              </a>
            ))}
          </div>
        </section>

        <section className="section gallery-section">
          <SectionHeader
            eyebrow="Gallery & updates"
            title="THE HACKATHON EXPERIENCE."
            copy="Official imagery and verified updates will be published here."
          />
          <div className="gallery-grid reveal">
            {[
              'Event Highlights',
              'Behind the Scenes',
              'Workshops',
              'Team Collaboration',
              'Previous Event Moments',
            ].map((title, index) => (
              <div className={`gallery-placeholder gallery-${index + 1}`} key={title}>
                <div className="placeholder-pattern" />
                <span>IMAGE PLACEHOLDER</span>
                <h3>{title}</h3>
              </div>
            ))}
          </div>
          <div className="announcements reveal">
            <div>
              <span className="pulse">
                <i /> LIVE BOARD
              </span>
              <h3>EVENT ANNOUNCEMENTS</h3>
            </div>
            {[
              'Important Updates',
              'Registration Announcements',
              'Schedule Changes',
              'Event Notifications',
            ].map((item) => (
              <div className="announcement" key={item}>
                <span>TBA</span>
                <b>{item}</b>
                <small>No updates published yet</small>
              </div>
            ))}
          </div>
        </section>

        <section id="faq" className="section faq-section">
          <SectionHeader eyebrow="Frequently asked" title="GOT QUESTIONS? WE HAVE ANSWERS." />
          <Accordion items={faqs} type="faq" />
        </section>

        <section className="section department-section">
          <div className="department-panel reveal">
            <div className="department-logo">
              <img src={simatsLogo.src} alt="SIMATS Engineering" />
            </div>
            <div className="department-copy">
              <span className="eyebrow">
                <i />
                Organizing department
              </span>
              <h2>
                DEPARTMENT OF
                <br />
                <em>SMART MATERIALS</em>
              </h2>
              <h3>SIMATS ENGINEERING</h3>
              <p>Organized by the Department of Smart Materials, SIMATS Engineering.</p>
            </div>
          </div>
        </section>

        <section id="team" className="section team-section">
          <SectionHeader
            eyebrow="People behind the event"
            title="MEET THE ORGANIZING COMMITTEE"
            copy="The team behind HACK 2027."
          />
          <div className="committee-grid">
            {committee.map((member, index) => (
              <article className="profile-card reveal" key={member.name}>
                <span className="profile-index">{String(index + 1).padStart(2, '0')}</span>
                <div
                  className="profile-avatar"
                  aria-label={`Editable profile image placeholder for ${member.name}`}
                >
                  <Icon name="users" size={33} />
                  <small>ADD PHOTO</small>
                </div>
                <h3>{member.name}</h3>
                <p className="profile-designation">{member.designation}</p>
                <i />
              </article>
            ))}
          </div>
          <div className="faculty-block reveal">
            <div
              className="faculty-avatar"
              aria-label="Editable profile image placeholder for Dr. Jothi Arunachalam"
            >
              <Icon name="users" size={38} />
              <small>ADD PHOTO</small>
            </div>
            <div>
              <span>FACULTY IN-CHARGE</span>
              <h3>DR. JOTHI ARUNACHALAM</h3>
            </div>
            <div className="faculty-mark">FIC</div>
          </div>
        </section>

        <section id="contact" className="section contact">
          <div className="contact-panel reveal">
            <div>
              <span className="eyebrow">
                <i />
                Contact
              </span>
              <h2>
                GET IN TOUCH
                <br />
                <em>WITH OUR TEAM.</em>
              </h2>
              <p>Connect directly with the HACK 2027 organizing team.</p>
            </div>
            <div className="contact-list">
              <div>
                <Icon name="users" />
                <span>
                  <small>ORGANIZING TEAM</small>
                  <b>HACK 2027 Organizing Committee</b>
                </span>
              </div>
              <div>
                <Icon name="mail" />
                <span>
                  <small>FACULTY IN-CHARGE</small>
                  <b>Dr. Jothi Arunachalam</b>
                </span>
              </div>
              <div>
                <Icon name="orbit" />
                <span>
                  <small>ORGANIZING DEPARTMENT</small>
                  <b>Department of Smart Materials · SIMATS Engineering</b>
                </span>
              </div>
              <a href={`mailto:${eventConfig.email}`}>
                <Icon name="mail" />
                <span>
                  <small>OFFICIAL EMAIL</small>
                  <b>{eventConfig.email}</b>
                </span>
              </a>
              <a href="tel:+918870986482">
                <Icon name="phone" />
                <span>
                  <small>CONTACT 01</small>
                  <b>+91 8870986482</b>
                </span>
              </a>
              <a href="tel:+919344334585">
                <Icon name="phone" />
                <span>
                  <small>CONTACT 02</small>
                  <b>+91 93443 34585</b>
                </span>
              </a>
            </div>
            <div className="social-actions">
              <ActionLink href={eventConfig.whatsappUrl} className="social-button">
                <Icon name="message" /> Join Our WhatsApp Community
              </ActionLink>
              <ActionLink href={eventConfig.instagramUrl} className="social-button">
                <Icon name="instagram" /> Follow Us on Instagram
              </ActionLink>
              <ActionLink
                href={eventConfig.email ? `mailto:${eventConfig.email}` : ''}
                className="social-button"
              >
                <Icon name="mail" /> Contact Organizers
              </ActionLink>
            </div>
          </div>
        </section>
      </main>

      <footer>
        <div className="footer-top">
          <div className="footer-brand">
            <img src={hackLogo.src} alt="HACK 2027" />
            <p>
              24 HOURS. ONE CHALLENGE.
              <br />
              INFINITE POSSIBILITIES.
            </p>
          </div>
          <div className="footer-links">
            <span>QUICK LINKS</span>
            {[
              ['Home', 'home'],
              ['About', 'about'],
              ['Domains', 'domains'],
              ['Committee', 'team'],
              ['Timeline', 'timeline'],
              ['Prizes', 'prizes'],
              ['Registration', 'registration'],
              ['Contact', 'contact'],
            ].map(([label, id]) => (
              <a href={`#${id}`} key={id}>
                {label}
              </a>
            ))}
          </div>
          <div className="footer-institution">
            <span>ORGANIZED BY</span>
            <img src={simatsLogo.src} alt="SIMATS Engineering" />
            <p>
              Department of Smart Materials
              <br />
              SIMATS Engineering
              <br />
              Faculty In-Charge: Dr. Jothi Arunachalam
            </p>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© 2027 HACK 2027. ALL RIGHTS RESERVED.</span>
          <div>
            <ActionLink href={eventConfig.instagramUrl}>
              <Icon name="instagram" size={18} />
            </ActionLink>
            <ActionLink href={eventConfig.whatsappUrl}>
              <Icon name="message" size={18} />
            </ActionLink>
            <ActionLink href={eventConfig.linkedinUrl}>
              <Icon name="linkedin" size={18} />
            </ActionLink>
          </div>
          <span>BUILT FOR THE BOLD.</span>
        </div>
      </footer>

      <button
        className={`back-top ${showTop ? 'show' : ''}`}
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        aria-label="Back to top"
      >
        ↑
      </button>
    </div>
  )
}
