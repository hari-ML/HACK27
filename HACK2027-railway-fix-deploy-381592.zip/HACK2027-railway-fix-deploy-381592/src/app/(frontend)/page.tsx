import { Hack2027App } from './components/Hack2027App'

export default function HomePage() {
  return <Hack2027App />
}
